insert_site.php is for insertion of data in MySql database and its table
DB=medicines
table=medicines.medicine_db
to check it copy this folder in xampp/htdocs and
Now Run this in localhost via link http://localhost:8080/Final/
Now open insert_site.php for insertion in table, before it create table
search.html for searching the result from database.
I have created .html for just checking, but you should put only selected codes in your file
result.php will show the results